    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Halaman Tidak Ditemukan</title>
        <link href="https://fonts.googleapis.com/css?gfamily=Montserrat:200,400,700" rel="stylesheet">

        <link type="text/css" rel="stylesheet" href="css/gagal_login.css" />
    </head>
    <body>
        <div id="notfound">
            <div class="notfound">
                <div class="notfound-404">
                    <h1>Ooopss!</h1>
                    <h2>SILAHKAN LOGIN KEMBALI</h2>
                </div>
                <a href="index.php" title="kembali ke halaman login">GO TO HOMEPAGE</a>
            </div>
        </div>
    </body>
    </html>